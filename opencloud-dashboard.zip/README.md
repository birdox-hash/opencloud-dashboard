# OpenCloud Dashboard

A self-hosted, open-source cloud app dashboard. Track, install, and manage apps like Jellyfin, Nextcloud, and offline Wikis. Includes a web UI with tiles, status monitoring, and a curated one-click app store for nerds. Fully modular and ready for expansion.