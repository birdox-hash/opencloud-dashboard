<template>
  <div class="status-bar">
    <span>Loading system status…</span>
    <span class="offline">Offline</span>
  </div>
</template>

<script>
export default { name: "StatusBar" };
</script>